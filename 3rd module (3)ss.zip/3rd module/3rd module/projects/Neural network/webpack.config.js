'use strict'

module.exports = {
    entry: './main',
    output: {
        filename: './dist/build.js'
    }
};