'use strict'

window['nn'] = require('./lib/nn');
window['imgUtil'] = require('./lib/imgUtil');